Cleaned website files created by ChatGPT.
Files:
- index.html
- assets/styles.css
- assets/script.js

Next steps:
1) Upload your real images into assets/img/ and update <img> src attributes in index.html.
2) If you want me to integrate all original detailed styles and exact visual tweaks from your Canva export, I can continue and port remaining CSS rules into styles.css (this will make the styles file larger but fully match the original).
3) If you want contact form to send emails, provide SMTP or endpoint details.

Original uploaded file content was used as source for text and structure. Reference: uploaded file (index.html.txt).